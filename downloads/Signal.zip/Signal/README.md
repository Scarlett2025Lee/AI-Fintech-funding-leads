# Signal · Local job-search website

React + TypeScript + Vite, with a small Node.js 24 HTTP server and embedded SQLite. The website runs on your own computer, stores data in the project folder, and needs no Tauri, Rust, Python, database server, or cloud account. Existing funding digests in `../weeks/` are unchanged.

For Windows on D:, see [中文启动说明](START_HERE.zh-CN.md).

## Current capabilities (v0.2)

- Funding Feed retrieves RSS/Atom from FinSMEs, FinTech Global and Tech.eu. It uses seven calendar days including today in America/New_York, filters AI/Fintech funding, excludes obvious non-US/late-stage/debt/acquisition news, and conservatively extracts company, stage and amount text. Unknown headquarters/stages remain unverified.
- A user must read the source and confirm US headquarters, Pre-seed through Series B, and the actual announcement date before saving a company/funding round. Article publication date is not assumed to be the financing date. Currency and investors are not invented. Reports export reviewed rounds separately from pending candidates, with cross-source round deduplication.
- The enabled-by-default weekly schedule checks at startup/every 15 minutes. Successful or partial runs become due after seven days; all-source failures retry no sooner than six hours. While the website is stopped it cannot fetch; next start catches up for the current week only. Manual generation and schedule pause are available.
- Companies supports search/filtering and saved company X/LinkedIn, founder LinkedIn/public contacts, business summary, HQ/offices, public/recruiting email and phone, source/check dates, and explicit official PM/GTM/Data job titles with URL/quoted evidence/check date. This version requires manual source-backed entry of detailed profiles; automatic founder/contact/website enrichment is not implemented.
- Hiring unknown is distinct from a checked absence of relevant jobs. Official jobs indicate a hiring signal at the checked date, not a claim about company strategy. Past contact/job history is retained when removing profile displays.
- The other standalone Contacts/CRM/email/matching/follow-up pages remain scaffolded. No email is sent. No fake companies are seeded.

## Source access and coverage

Public RSS feeds have limited history and can fail, block clients or change their URL. Coverage limits and failures are shown per source; zero retrieved records do not establish no funding occurred. Heuristic extraction produces candidates requiring review, not verified facts. Historical Markdown digests are not silently imported.

Live publisher access in the current cloud instance failed at the outbound proxy (CONNECT 403); successful real feed retrieval is **not yet validated**. Parsing and complete report/review/company/HTTP workflows passed with clearly fictional fixtures, and Chromium verified the actual blocked-source state. Required host additions were saved in the environment draft; to finish cloud live validation review/save those settings and publish the environment. The draft does not change networking on Windows; test Generate locally after upgrading. Destinations: www.finsmes.com, fintech.global, tech.eu, plus their configured www/non-www redirects. No API key is needed. Production/development launchers respect inherited HTTP proxy settings via Node's --use-env-proxy.

## Development

Use Node.js 24.19.x or later within version 24 (its built-in `node:sqlite` supplies SQLite) and npm. From this `web` directory:

```sh
npm ci
npm run dev
```

This starts the API on loopback port 1421 and Vite on loopback port 1420. Open `http://127.0.0.1:1420` **on the same computer**. The Vite proxy forwards `/api` to the local backend. Ctrl+C stops both processes. `npm run dev:ui` alone starts only the frontend and cannot supply database counts.

## Run the built website

```sh
npm run build
npm start
```

Open `http://127.0.0.1:1421` on the computer running the server. This is a local website, not a published Internet address. Servers in a cloud task do not make your laptop's localhost work. The service binds only to `127.0.0.1` and rejects unrecognized Host headers; do not expose this personal-data scaffold to the Internet without a separate deployment/authentication design.

The Windows launcher `Start-Signal.cmd` calls `Start-Signal.ps1`. It requires the project to be on D:, downloads portable Node 24.19.0 from nodejs.org on first use, checks the official SHA-256 manifest, installs locked dependencies, builds the website, and starts it. Tools, npm cache, process temporary files, and database all use directories under the project on D:. It needs Internet access for the first setup, but does not install Node globally. The launcher prints five progress stages, keeps the CMD window open on exit, and saves diagnostics under `.cache/logs/`. Once the health endpoint confirms SQLite is connected, it opens Chrome with a separate profile/cache under the project on D:. `Open-Signal.cmd` remains available to reopen the browser. The launcher owns its server process and stops it when interrupted.

The Windows launchers have not been executed in this Linux environment. The Node/HTTP/SQLite workflow has been tested here. Windows itself, PowerShell, antivirus, and an already installed browser may still use system files on C:; the application cannot guarantee zero system-disk writes.

## Storage

By default, `data/signal.sqlite3` lives under this project, regardless of the shell's working directory. Override it with the absolute path `SIGNAL_DATA_DIR`; relative/empty values are rejected. An unavailable directory causes startup to fail, without a fallback to AppData. Default production port is 1421; `SIGNAL_PORT` can override it when running just the built server. Development's Vite proxy and the Windows browser launcher use 1421.

Migrations 001–003 are applied transactionally in order using `PRAGMA user_version`, preserving a populated v1 database. Existing records survive restart. A database created by a newer application version is rejected. Foreign keys are enabled per connection. No sample companies or personal documents are seeded. If you used an older desktop scaffold, close it and back up its database before copying it to the new selected data directory; no old data is moved or deleted automatically.

Amounts use integer minor units with an explicit currency. Funding dates use `YYYY-MM-DD`; future write endpoints should normalize timestamps to UTC ISO 8601 ending in `Z`. Match scores range from 0 to 100, and each match names exactly one resume or project with a rationale. Outreach protects linked company/contact history from deletion. Deleting outreach cascades its drafts, matches, and reminders. The backend exposes typed funding/report/review/export, company-profile, health and aggregate endpoints. JSON writes have size/origin checks; arbitrary SQL and filesystem operations are not exposed.

Back up the entire `data` folder with the server stopped before upgrades. Its contents are private plain-text SQLite data and are ignored by Git. Resume uploads have not yet been built.

## Offline layout preview

```sh
npm run preview:export
```

Copy `dist/signal-preview.html` to any folder on D: and open that file in Chrome or Edge. Scripts and styles are embedded. This is a navigation/layout preview only: it does not connect to SQLite or save records. Use the full local website for SQLite.

## Validation

```sh
npm run build
npm test
npm run test:server
npm run test:schema
```

UI tests cover funding review/generation/errors, company source links/editing, navigation, routes, offline state, counts and retry. Server tests cover legacy migration, date/exclusion/deduplication logic, review/evidence validation, retained contact history, complete HTTP mutations/exports, persistence, routing and access boundaries. Schema tests use Python 3's standard library as an optional developer check; Python is not needed to run the website. On Windows, `py -3 scripts/check_schema.py` is an alternative.

## Structure

```text
src/App.tsx                         Shell, routes, dashboard, placeholders
src/lib/database.ts                 Typed HTTP client
server/database.mjs                 Local storage, migrations, aggregate SQL
server/app.mjs                      HTTP API and built static website
server/index.mjs                    Server lifecycle and loopback binding
database/migrations/                Versioned schema upgrades
scripts/dev.mjs                     Frontend + backend development runner
Start-Signal.cmd / .ps1             D-drive Windows setup/start
Open-Signal.cmd / .ps1              Separate D-drive Chrome profile
```

Next: validate live source access on the target machine, then add source-backed company enrichment if requested.

## Automatic updates (v0.3)

Windows users on older versions run the one-time downloads/Install-Signal.zip bootstrap. It pins the installer script's SHA-256, downloads the HTTPS release manifest and ZIP, verifies ZIP/file hashes, stages dependencies on D:, and calls the same transactional Node updater used by normal startup. Existing files are backed up rather than blindly overwritten. All tools/caches/backups remain below D:\Signal. First bootstrap requires stopping the old server; subsequent managed restarts are automatic.

Start-Signal.ps1 holds an exclusive launch lock, ensures Node/dependencies, checks the channel, and restarts itself after an update so new startup instructions take effect. The website can request a managed restart via a JSON POST; the server closes SQLite and exits with code 75. The launcher then updates while the website is stopped, rebuilds, checks exact release version and DB health, confirms, and opens Chrome. Unmanaged npm start sessions show restart instructions instead of trying to terminate an unknown parent.

Update packages are limited to this GitHub repository and program-path allowlist. No archive entry can target data, tools, caches, parent paths, device names, or linked program paths. Installed file inventories permit removing obsolete managed files while retaining user-created unknown files. SQLite is snapshotted before migration; previous dependency directories are retained by rename. Interrupted/unconfirmed or failed startups restore program, dependencies, and the pre-update database. Once a release is healthy and confirmed, later user activity is not automatically rolled back. Keep two generated rollback directories; generated backups are private data and excluded from packages.

GitHub/network/checksum failure leaves current code in place. Failed releases are temporarily blocked until a newer version is published. A Git checkout is not automatically replaced. Updates rely on public/noninteractive HTTPS access to the configured repository; no credentials are embedded. TLS is always verified. Windows process coordination is syntax-checked but not fully Windows-tested; core upgrade/recovery and actual packaged-server startup were tested in an isolated Linux installation with a retained legacy DB.

To publish future iterations: bump package.json/package-lock.json version, run npm run release, then commit/push source, downloads/Signal.zip, SHA file, update.json and generated installer assets together to codex/signal-web. Never publish a ZIP and manifest from different builds. The release script creates release.json inside the ZIP with per-file hashes; it is ignored in the working checkout. Use a strictly newer semantic version so installed clients receive fixes. No further user file replacement is required after bootstrap.
